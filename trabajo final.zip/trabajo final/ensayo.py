
from kivy.app import App
from kivy.base import runTouchApp
from kivy.lang import Builder
from kivy.properties import ListProperty
from kivy.uix.boxlayout import BoxLayout
import cv2
from kivy.graphics import Line,Rectangle
import numpy as np
from kivy.uix.screenmanager import ScreenManager, Screen, FadeTransition
from kivy.uix.floatlayout import FloatLayout
#from kivy.uix.widget import widget
from kivy.core.window import Window
 
#Window.clearcolor:(0,0,1,0.5)

class MyScreenManager(ScreenManager):
    pass
class Inicio(Screen):
    pass
class FirstScreen(Screen):
    pass
class SecondScreen(Screen):
    def negativo(self):
        I=cv2.imread("IMG0.jpg")
        Ineg=255-I
        cv2.imwrite("negativo.jpg",Ineg)
        with self.canvas:
            Rectangle(source="negativo.jpg",pos=(40,305),size=(300,300))#posicion buena
    def color(self):
        I=cv2.imread("IMG1.jpeg")
        L=cv2.cvtColor(I,cv2.COLOR_RGB2YUV)
        cv2.imwrite("color.jpg",L)
        with self.canvas:
            Rectangle(source="color.jpg",pos=(40,305),size=(300,300))
    def binaria(self):
        I=cv2.imread("IMG2.jpeg",0)
        t,Mbin=cv2.threshold(I,140,255,cv2.THRESH_BINARY)
        cv2.imwrite("binaria.jpg",Mbin)
        with self.canvas:
            Rectangle(source="binaria.jpg",pos=(40,305),size=(300,300))
    def ecual(self):
        I=cv2.imread("IMG4.jpg",0)
        E=cv2.equalizeHist(I)
        cv2.imwrite("ecua.jpg",E)
        with self.canvas:
            Rectangle(source="ecua.jpg",pos=(40,305),size=(300,300))
    def dilat(self):
        I=cv2.imread("IMG0.jpg",0)
        EE=cv2.getStructuringElement(cv2.MORPH_RECT,(6,6))
        D=cv2.dilate(I,EE)
        cv2.imwrite("dilat.jpg",D)
        with self.canvas:
            Rectangle(source="dilat.jpg",pos=(40,305),size=(300,300))
    def eroc(self):
        I=cv2.imread("IMG1.jpeg",0)
        EE2=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(15,15))
        E=cv2.erode(I,EE2)
        cv2.imwrite("eroc.jpg",E)
        with self.canvas:
            Rectangle(source="eroc.jpg",pos=(40,305),size=(300,300))
    def mediana(self):
        I=cv2.imread("IMG4.jpg",0)
        M=cv2.medianBlur(I,3)
        cv2.imwrite("mediana.jpg",M)
        with self.canvas:
            Rectangle(source="mediana.jpg",pos=(40,305),size=(300,300))
    def sobel(self):
        I=cv2.imread("IMG3.jpeg",0)
        Fs=cv2.Sobel(I,-1,1,1)
        cv2.imwrite("sobel.jpg",Fs)
        with self.canvas:
            Rectangle(source="sobel.jpg",pos=(40,305),size=(300,300))
    def canny(self):
        I=cv2.imread("IMG2.jpeg",0)
        mascara=np.array([[-1,-1,-1],[-1,8,-1],[-1,-1,-1]])
        DP=cv2.filter2D(I,-1,mascara)
        cv2.imwrite("canny.jpg",DP)
        with self.canvas:
            Rectangle(source="canny.jpg",pos=(40,305),size=(300,300))
    def GL(self):
        I=cv2.imread("IMG0.jpg",0)
        Rgauss=cv2.GaussianBlur(I,(5,5),0.5)
        T2,UMBRAL2=cv2.threshold(Rgauss,155,255,cv2.THRESH_BINARY)
        Ilap=cv2.Laplacian(UMBRAL2,-1)
        cv2.imwrite("gl.jpg",Ilap)
        with self.canvas:
            Rectangle(source="gl.jpg",pos=(40,305),size=(300,300))
    pass


root_widget = Builder.load_string('''
#:import FadeTransition kivy.uix.screenmanager.FadeTransition
MyScreenManager:
    transition: FadeTransition()
    Inicio:
    FirstScreen:
    SecondScreen:       
<Inicio>:
    name: 'inicio'
    canvas.before:
        Rectangle:
            pos: self.pos
            size: self.size
            source: 'logo.png'
    FloatLayout:
        Button:
            text: 'Imagenes'
            size_hint:(0.4,0.1)
            pos_hint: {"center_x": .5, "center_y": .1}
            font_size:"20sp"
            border : 10,10,10,10
            background_color: ("cyan")
            on_release: app.root.current = 'first'
        
    
<FirstScreen>:
    name: 'first'
    GridLayout:
        cols:2
        rows:3
        Image:
            source:"IMG0.jpg"
        Image:
            source:"IMG1.jpeg"
        Image:
            source:"IMG2.jpeg"
        Image:
            source:"IMG3.jpeg"
        Image:
            source:"IMG4.jpg"
        Button:
            background_normal : 'flecha1.png'
            on_release: app.root.current = 'second'
    FloatLayout:
        Button:
            text: 'Atras'
            size_hint:(0.80,0.05)
            pos_hint: {"center_x": .5}
            font_size:"20sp"
            border : 16,16,16,16
            background_color: ("cyan")
            on_release: app.root.current = 'inicio'
    
    
<SecondScreen>:
    name: 'second'
    BoxLayout:
        size_hint:1,0.5
        width:100
        orientation:'vertical'
        Button:
            id:OK
            text:"Negativo"
            background_color: ("green")
            font_size:"20sp"
            font_name:'Arial'
            on_release:root.negativo()
        
        Button:
            id:'OK'
            text:"Cambio de color"
            background_color: ("green")
            font_size:"20sp"
            font_name:'Arial'
            on_release:root.color()

        Button:
            id:'OK'
            text:"Ecualizacion"
            background_color: ("green")
            font_size:"20sp"
            font_name:'Arial'
            on_release:root.ecual()
            
        Button:
            id:'OK'
            text:"Binarizada"
            background_color: ("yellow")
            font_size:"20sp"
            font_name:'Arial'
            on_release:root.binaria()
            
        Button:
            id:'OK'
            text:"Dilatacion"
            background_color: ("yellow")
            font_size:"20sp"
            font_name:'Arial'
            on_release:root.dilat()
            
        Button:
            id:'OK'
            text:"Erocion"
            background_color: ("yellow")
            font_size:"20sp"
            font_name:'Arial'
            on_release:root.eroc()
            
        Button:
            id:'OK'
            text:"Filtro sobel"
            background_color: ("red")
            font_size:"20sp"
            font_name:'Arial'
            on_release:root.sobel()
            
        Button:
            id:'OK'
            text:"Filtro de la mediana"
            background_color: ("red")
            font_size:"20sp"
            font_name:'Arial'
            on_release:root.mediana()
            
        Button:
            id:'OK'
            text:"Canny"
            background_color: ("orange")
            font_size:"20sp"
            font_name:'Arial'
            on_release:root.canny()
            
        Button:
            id:OK
            text:"Gauss Laplaciano"
            background_color: ("orange")
            font_size:"20sp"
            font_name:'Arial'
            on_release:root.GL()
        Button:
            text: 'volver'
            background_color: ("cyan")
            font_size:"20sp"
            font_name:'Arial'
            on_release: app.root.current = 'first'

''')

class ScreenManagerApp(App):
    def build(self):
        return root_widget


ScreenManagerApp().run()